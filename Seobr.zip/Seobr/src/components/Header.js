// Ändere den Haupt-Header
<h1 className="text-4xl font-bold text-purple-600">
  SEO Visionary
</h1>