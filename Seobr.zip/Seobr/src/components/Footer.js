import React from 'react';

const Footer = () => {
  return (
    <footer>
      <p>&copy; 2024 SEO Tool</p>
    </footer>
  );
};

export default Footer;